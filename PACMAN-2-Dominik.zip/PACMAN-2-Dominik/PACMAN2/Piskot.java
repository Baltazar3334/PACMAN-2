
/**
 * Write a description of class Piskot here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import fri.shapesge.Kruh;
public class Piskot {
    /**
     * Constructor for objects of class Piskot
     */
    private Kruh piskot;
    public Piskot() {
        this.piskot = new Kruh();
        this.piskot.zmenFarbu("yellow");
        this.piskot.zobraz();
        
    }
}
