
/**
 * Write a description of class Stvorec here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import fri.shapesge.Stvorec;
public class Stvorce {
    /**
     * Constructor for objects of class Stvorec
     */
    private Stvorec stvorec;
    public Stvorce() {
        stvorec = new Stvorec();
        stvorec.zobraz();
        
    }
}
