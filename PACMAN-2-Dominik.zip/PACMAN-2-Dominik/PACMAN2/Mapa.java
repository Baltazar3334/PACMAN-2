
/**
 * Write a description of class Mapa here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import fri.shapesge.Obdlznik;
public class Mapa {
    /**
     * Constructor for objects of class Mapa
     */
    private Obdlznik obdlznik;
    public Mapa() {
        this.obdlznik = new Obdlznik();
        this.obdlznik.zobraz();
    }
}
